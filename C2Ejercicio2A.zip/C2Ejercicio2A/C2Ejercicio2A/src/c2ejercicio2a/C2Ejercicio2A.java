
package c2ejercicio2a;


public class C2Ejercicio2A {

    
    public static void main(String[] args) {
           Menu menu = new Menu();
           menu.setVisible(true);
    }
    
}